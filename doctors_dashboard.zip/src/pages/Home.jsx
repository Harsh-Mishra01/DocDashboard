import DoctorProfile from "../components/DoctorsProfile";
import VisitFrequency from "../components/VisitFrequency";
import PotentialVsROI from "../components/PotentialVsROI";
import CampaignList from "../components/CurrentCamp";
import SuggestedTopics from "../components/SuggestedTopics";
import Preferences from "../components/Preferences";
import Navigation from "../components/NavigationButtons";
import BusinessImpactBarChart from "../components/BusinessImpactCharts";
import Dropdown from "../components/DropDown";
import { useState } from "react";
import SearchComponent from "../components/SearchBar";

const Home = () => {
  const initialPiechartData = [
    { name: "Potential", value: 85, color: "#07A241" }, 
    { name: "RCPA", value: 15, color: "#A7F3D0" }, 
  ];

  const initialBargraphData = [
    { month: "Jan", value: 8000 },
    { month: "Feb", value: 7000 },
    { month: "Mar", value: 6000 },
    { month: "Apr", value: 7000 },
    { month: "May", value: 5000 },
    { month: "Jun", value: 6000 },
    { month: "Jul", value: 7000 },
  ];

  const [piechartData, setPiechartData] = useState(initialPiechartData);
  const [bargraphData, setBargraphData] = useState(initialBargraphData);
  return (
    <div className="grid grid-cols-[1fr_7fr]">
      <div className="flex justify-center gap-2 m-2">
        <DoctorProfile path={window.location.pathname}/>
      </div>
      <div>
        <div className="rounded-lg flex flex-col gap-2 m-2">
          <div className="flex justify-center h-14 mb-6">
            <SearchComponent />
            <Navigation />
          </div>
          <VisitFrequency />
        </div>
        <div className="grid lg:grid-cols-[1fr_1fr_1fr] md:grid-cols-1 gap-2 m-2">
          <div className="shadow-xl border-2 border-slate-200 flex justify-evenly items-center flex-col rounded-lg">
            <Dropdown
              setPiechartData={setPiechartData}
              setBargraphData={setBargraphData}
            />
            <PotentialVsROI data={piechartData} />
          </div>
          <BusinessImpactBarChart data={bargraphData} />
          <div>
            <CampaignList name="Toncat" title="Title" isProcured={true} />
          </div>
        </div>
        <div className="grid lg:grid-cols-[3fr_2fr] grid-rows-1 md:grid-cols-1 gap-2 m-2">
          <SuggestedTopics />
          <Preferences />
        </div>
      </div>
    </div>
  );
};

export default Home;
