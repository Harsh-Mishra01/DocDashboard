import Navigation from "../components/NavigationButtons";
import DoctorProfile from "../components/DoctorsProfile";
import EducationTable from "../components/EducationTable";
import ClinicDetailsTable from "../components/tableComponents/ClinicDetailsTable"
import { useState } from "react";
import AwardsRecoTable from "../components/tableComponents/AwardsRecoTable";
import PublicationsTable from "../components/tableComponents/Publication";
import TrialTable from "../components/tableComponents/TrialTable";
import EventsTable from "../components/tableComponents/EventsTable";
import PressTable from "../components/tableComponents/PressTable";

const DocProfilePage = () => {
  const [activeItem, setActiveItem] = useState(null);

  const renderTable = () => {
    if (activeItem === "education") {
      return <EducationTable />;
    } else if (activeItem === "clinicDetails") {
      return <ClinicDetailsTable />;
    } 
    else if (activeItem === "awards") {
      return <AwardsRecoTable/>;
    }
    else if (activeItem === "Publications") {
      return <PublicationsTable/>;
    }
    else if (activeItem === "Trials") {
      return <TrialTable/>;
    }
    else if (activeItem === "Events") {
      return <EventsTable/>;
    }
    else if (activeItem === "Press") {
      return <PressTable/>;
    }
    else {
      return <EducationTable />;
    }
  };

  return (
    <div className="grid grid-cols-[1fr_7fr] m-2">
      <div className="flex">
        <DoctorProfile
          path={window.location.pathname}
          setActiveItem={setActiveItem}
          activeItem={activeItem}
        />
      </div>
      <div>
        <div className="rounded-lg m-2 flex flex-col gap-2">
          <Navigation />
        </div>
        <div>
          {renderTable()}
        </div>
      </div>
    </div>
  );
};

export default DocProfilePage;
