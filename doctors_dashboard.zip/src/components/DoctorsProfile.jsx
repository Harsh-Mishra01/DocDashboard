// import { useState } from "react";

const DoctorProfile = ({ path,activeItem,setActiveItem }) => {
  // const [activeItem, setActiveItem] = useState(null);
  // const [dropdownVisible, setDropdownVisible] = useState(false);
  // const [publicationValue, setPublicationValue] = useState("Publication");

  const handleClick = (item) => {
    setActiveItem(item);
    // setDropdownVisible(false); // Close the dropdown when an item is clicked
  };

  // const handleDropdownSelect = (value) => {
  //   setPublicationValue(value);
  //   handleClick("publication");
  // };

  // const toggleDropdown = () => {
  //   setDropdownVisible(!dropdownVisible);
  // };
  return (
    <div className="bg-green-600 text-white p-3 rounded-2xl w-[270px] h-auto max-h-500 overflow-auto scroll-m-0 flex flex-col justify-between">
      {console.log(path)}
      <div>
        <img
          className="w-38 rounded-full mx-auto mb-4"
          src="../../public/images/dr_sarita_rao.png"
          alt="Dr. Sarita Rao"
        />
        {path == "/" ? (
          <>
            <div>
              <div>
                <h2 className="text-xl font-bold">Dr. Sarita Rao</h2>
                <p className="mb-2">Cardiologist</p>
              </div>
              <table>
                <tbody>
                  <tr>
                    <td className="text-sm font-bold">UID</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Doctor Name</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Cell Phone:</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Email ID</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Specialty</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Sub-Specialty</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Qualification</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Years of Experience</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Area</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                  <tr>
                    <td className="text-sm font-bold">Hobbies</td>
                    <td>:</td>
                    <td> xxxxxxxxx</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </>
        ) : (
          <>
            <div className="mb-5">
              <div className="text-lg font-bold text-white">Dr. Sarita Rao</div>
              <div className="text-sm font-medium text-white">Cardiologist</div>
            </div>
            <nav className="flex flex-col gap-2">
              <button
                onClick={() => handleClick("clinicDetails")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "clinicDetails"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Clinic Details
              </button>
              <button
                onClick={() => handleClick("education")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "education"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Education
              </button>
              <button
                onClick={() => handleClick("awards")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "awards"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Awards & Reco
              </button>
              <button
                onClick={() => handleClick("Publications")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "Publications"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Publications
              </button>
              <button
                onClick={() => handleClick("Trials")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "Trials"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Trials
              </button>
              <button
                onClick={() => handleClick("Events")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "Events"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Events
              </button>
              <button
                onClick={() => handleClick("Press")}
                className={`flex items-center gap-2 px-3 py-2 rounded-md transition duration-300 ${
                  activeItem === "Press"
                    ? "bg-white text-green-400"
                    : "bg-green-500 text-white"
                }`}
              >
                <i className="fas fa-home"></i>
                Press
              </button>
              {/* <div className="relative">
                <button
                  onClick={toggleDropdown}
                  className={`flex items-center justify-between gap-2 px-3 py-2 rounded-md transition duration-300 w-full ${
                    activeItem === "publication"
                      ? "bg-white text-green-400"
                      : "bg-green-500 text-white"
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <i className="fas fa-home"></i>
                    {publicationValue}
                  </span>
                  <i
                    className={`fas fa-chevron-${
                      dropdownVisible ? "up" : "down"
                    }`}
                  ></i>
                </button>
                {dropdownVisible && (
                  <div className="absolute mt-2 w-full rounded-md shadow-lg bg-green-500 ring-1 ring-black ring-opacity-5 text-white z-10">
                    <ul className="py-1">
                      <li
                        onClick={() => handleDropdownSelect("Publication")}
                        className="block px-4 py-2 text-sm cursor-pointer hover:bg-green-400"
                      >
                        Publication
                      </li>
                      <li
                        onClick={() => handleDropdownSelect("Trials")}
                        className="block px-4 py-2 text-sm cursor-pointer hover:bg-green-400"
                      >
                        Trials
                      </li>
                      <li
                        onClick={() => handleDropdownSelect("Events")}
                        className="block px-4 py-2 text-sm cursor-pointer hover:bg-green-400"
                      >
                        Events
                      </li>
                      <li
                        onClick={() => handleDropdownSelect("Press")}
                        className="block px-4 py-2 text-sm cursor-pointer hover:bg-green-400"
                      >
                        Press
                      </li>
                    </ul>
                  </div>
                )}
              </div> */}
            </nav>
          </>
        )}
      </div>
      {path == "/" ? (
        <>
          <div>
            <div>
              {/* <button className="mt-4 bg-blue-500 text-white py-2 px-4 rounded-lg">Digital Presence</button> */}
              <div className="bg-green-600 rounded-md p-2">
                <div className="bg-white text-gray-900 rounded-3xl text-center px-4 py-2 mb-4">
                  Digital Presence
                </div>
                <div className="flex space-x-4">
                  <a
                    href="#"
                    className="text-green-600 bg-white hover:bg-gray-300 rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <i className="fab fa-facebook-f text-xl text-blue-500"></i>
                  </a>
                  <a
                    href="#"
                    className="text-green-600 bg-white hover:bg-gray-300 rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <i className="fab fa-youtube text-xl text-red-500"></i>
                  </a>
                  <a
                    href="#"
                    className="text-green-600 bg-white hover:bg-gray-300 rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <i className="fab fa-linkedin text-xl text-blue-500"></i>
                  </a>
                  <a
                    href="#"
                    className="text-green-600 bg-white hover:bg-gray-300 rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <div className="text-xl bg-gradient-to-r from-orange-400 to-pink-600 bg-clip-text text-transparent">
                      <i className="fab fa-instagram"></i>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
          <div className="text-sm flex flex-col justify-between">
            <div>
              {/* <button className="mt-4 bg-blue-500 text-white py-2 px-4 rounded-lg">Digital Presence</button> */}
              <div className="bg-green-600 rounded-md p-2">
              <div className="bg-white text-gray-900 rounded-3xl text-center px-4 py-2 mb-4">
                  Doctors Platform
                </div>
                <div className="flex space-x-4 justify-center">
                  <a
                    href="#"
                    className="text-green-600 bg-white rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <i>Practo</i>
                  </a>
                  <a
                    href="#"
                    className="text-green-600 bg-white rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <i>Practo</i>
                  </a>
                  <a
                    href="#"
                    className="text-green-600 bg-white rounded-full w-12 h-12 flex items-center justify-center hover:text-green-900"
                  >
                    <i>Practo</i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : (
        <></>
      )}
    </div>
  );
};

export default DoctorProfile;
