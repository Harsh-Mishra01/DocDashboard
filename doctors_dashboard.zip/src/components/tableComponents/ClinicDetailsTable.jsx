import HospitalCard from '../HospitalAddress'; // Adjust the import path as necessary
import '../../styles/EducationTable.css'; // Adjust the import path as necessary

const ClinicsTable = () => {
  const hospitals = [
    {
      name: "Hegde Hospital",
      location: "Madhapur, Hyderabad",
      rating: 4.5,
      address: "67/68, Vittalrao Nagar, Landmark: Karachi Bakery Lane & Opposite Pizza Hut, Hyderabad",
      directions: "Get Directions",
      images: [
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50"
      ],
      promoMessage: "Practo takes the first step in Revolutionizing Healthcare Access for Patients, launches Practo Assured. If you are a doctor, read to know more."
    },
    {
      name: "Apollo Hospital",
      location: "Jubilee Hills, Hyderabad",
      rating: 4.8,
      address: "Road No 92, Jubilee Hills, Hyderabad",
      directions: "Get Directions",
      images: [
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50"
      ],
      promoMessage: "Apollo Hospital is committed to providing world-class healthcare. If you are a doctor, read to know more."
    },
    {
      name: "Care Hospital",
      location: "Banjara Hills, Hyderabad",
      rating: 4.7,
      address: "Road No 10, Banjara Hills, Hyderabad",
      directions: "Get Directions",
      images: [
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50",
        "https://via.placeholder.com/50"
      ],
      promoMessage: "Care Hospital ensures top-notch healthcare facilities. If you are a doctor, read to know more."
    }
  ];

  return (
    <div className="clinics-table space-y-4">
      {hospitals.map((hospital, index) => (
        <HospitalCard
          key={index}
          name={hospital.name}
          location={hospital.location}
          rating={hospital.rating}
          address={hospital.address}
          directions={hospital.directions}
          images={hospital.images}
          promoMessage={hospital.promoMessage}
        />
      ))}
    </div>
  );
};

export default ClinicsTable;
