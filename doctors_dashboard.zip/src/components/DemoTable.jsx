// const DemoTable = () => {
//   const data = [
//     {
//       institutionName: "American College of Cardiology",
//       degree: "FACC",
//       passingYear: "2013",
//       country: "United States",
//       state: "District of Columbia",
//       city: "Washington",
//       city1: "Washington",
//       city2: "Washington",
//     },
//     {
//       institutionName: "American College of Cardiology",
//       degree: "FACC",
//       passingYear: "2013",
//       country: "United States",
//       state: "District of Columbia",
//       city: "Washington",
//       city1: "Washington",
//       city2: "Washington",
//     },
//     {
//       institutionName: "American College of Cardiology",
//       degree: "FACC",
//       passingYear: "2013",
//       country: "United States",
//       state: "District of Columbia",
//       city: "Washington",
//       city1: "Washington",
//       city2: "Washington",
//     },
//     {
//       institutionName: "American College of Cardiology",
//       degree: "FACC",
//       passingYear: "2013",
//       country: "United States",
//       state: "District of Columbia",
//       city: "Washington",
//       city1: "Washington",
//       city2: "Washington",
//     },
//     {
//       institutionName: "American College of Cardiology",
//       degree: "FACC",
//       passingYear: "2013",
//       country: "United States",
//       state: "District of Columbia",
//       city: "Washington",
//       city1: "Washington",
//       city2: "Washington",
//     },
//     // Add more data as needed
//   ];

//   return (
//     <>
//       <div>
//         Training
//         <div className="red flex">
//           <div>
//             <p>institutionName</p>
//           </div>
//           <div className="flex w-[800px] green overflow-x-scroll">
//             <p className="blue min-w-[200px]">State</p>
//             <p className="blue min-w-[200px]">City</p>
//             <p className="blue min-w-[200px]">Country</p>
//             <p className="blue min-w-[200px]">Passing Year</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//           </div>
//         </div>
//         <div className="flex">
//         <div>
//             <p>institutionName</p>
//           </div>
//           <div className="flex w-[800px] green overflow-x-scroll">
//             <p className="blue min-w-[200px]">State</p>
//             <p className="blue min-w-[200px]">City</p>
//             <p className="blue min-w-[200px]">Country</p>
//             <p className="blue min-w-[200px]">Passing Year</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//             <p className="blue min-w-[200px]">Speciality</p>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default DemoTable;

import "../styles/EducationTable.css"

const DemoTable = () => {
  const data = [
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    {
      institutionName: "American College of Cardiology",
      degree: "FACC",
      passingYear: "2013",
      country: "United States",
      state: "District of Columbia",
      city: "Washington",
      city1: "Washington",
      city2: "Washington",
    },
    // Add more data as needed
  ];

  return (
    <>
      <h2 className="text-2xl font-semibold m-4 flex items-center">
        <p>Education</p>
        <img className="w-[80px] ml-2" src="../../public/images/edu.gif" alt="edupng" />
      </h2>
      <div className="flex cw mx-3 shadow-lg">
        <div className="min-w-[250px] text-center">
          <p className="py-4 px-2 bg-blue-400 text-white font-bold text-center rounded-md">Institution Name</p>
          {data.map((item, index) => {
            return <p key={index} className="py-4 bg-blue-100">{item.institutionName}</p>;
          })}
        </div>
        <div className="flex w-[1000px] overflow-x-scroll custom-scrollbar">
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">Degree-Speciality</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.degree}</p>;
          })}
          </div>
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">Passing-Year</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.passingYear}</p>;
          })}
          </div>
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">Country</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.country}</p>;
          })}
          </div>
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">State</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.state}</p>;
          })}
          </div>
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">City</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.city}</p>;
          })}
          </div>
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">City1</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.city1}</p>;
          })}
          </div>
          <div className="min-w-[150px]">
            <p className="py-4 px-2 bg-green-600 text-white font-bold text-center rounded-sm">City2</p>
            {data.map((item, index) => {
            return <p key={index} className="py-4 text-center odd:bg-white even:bg-green-200">{item.city2}</p>;
          })}
          </div>
        </div>
      </div>
    </>
  );
};

export default DemoTable;
