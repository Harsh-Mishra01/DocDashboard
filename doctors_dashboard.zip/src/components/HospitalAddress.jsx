const HospitalCard = ({ name, location, rating, address, directions, images, promoMessage }) => {
  return (
    <div className="m-2 border-2 border-gray-300 rounded overflow-hidden shadow-lg p-4 bg-white">
      <div className="text-xl font-semibold mb-2">{location}</div>
      <div className="text-blue-500 text-lg font-bold">
        <a href="#">{name}</a>
      </div>
      <div className="flex items-center my-2">
        <div className="text-green-500 font-semibold text-lg">{rating}</div>
        <div className="flex ml-2">
          {Array(Math.floor(rating)).fill().map((_, i) => (
            <svg key={i} className="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10 15l-5.39 2.83 1.03-6.01-4.37-4.26 6.05-.88L10 0l2.68 6.68 6.05.88-4.37 4.26 1.03 6.01z" />
            </svg>
          ))}
        </div>
      </div>
      <div className="text-sm mb-2">
        {address}
      </div>
      <div className="text-blue-500 mb-2">
        <a href="#">{directions}</a>
      </div>
      <div className="flex items-center space-x-1 mb-2">
        {images.slice(0, 4).map((image, index) => (
          <img key={index} className="w-8 h-8 rounded" src={image} alt="gallery" />
        ))}
        {images.length > 4 && (
          <div className="w-8 h-8 rounded bg-gray-200 flex items-center justify-center text-sm">
            +{images.length - 4}
          </div>
        )}
      </div>
      <div className="bg-gray-100 p-2 rounded">
        <div className="text-sm">
          {promoMessage} <a href="#" className="text-blue-500">Click here</a>
        </div>
      </div>
    </div>
  );
}

export default HospitalCard;
